Free source code for [Learn WPF MVVM - XAML, C# and the MVVM pattern book](http://leanpub.com/learnwpf) demos and do-it-yourself

# Get the book

Buy the book as [ebook or print](http://arnaudweil.blogspot.com/2016/07/learn-meteor-book-available.html).

# Get the source code

Just `git clone` that repository. If that sounds obscure to you, click the "Downloads" link at the left of this window.